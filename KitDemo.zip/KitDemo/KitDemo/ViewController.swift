//
//  ViewController.swift
//  KitDemo
//
//  Created by 朱建伟 on 2016/12/28.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//

import UIKit

class ViewController: UITableViewController {
    
    var showArray:[String] = ["弹出提示（JWAlertController）","自动轮播（JWAutoScrollView）","日期选择键盘 （JWDatePickerView）","消息图标（JWMessageView）","图片展示（JWPhotoBrowserViewController）","提示 （JWProgressHUD）","h5加载（WebViewController）","日历控件"]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        self.tableView.register(UITableViewCell.classForCoder(), forCellReuseIdentifier: "cell")
    }

    
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return showArray.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        
        cell?.accessoryType = .disclosureIndicator
        cell?.textLabel?.text = showArray[indexPath.row]
         
        return cell!
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0://alertController弹框
            let alertTestVc:AlertControllerTestViewController = AlertControllerTestViewController()
            alertTestVc.title = showArray[indexPath.row]
            self.navigationController?.pushViewController(alertTestVc, animated: true)
            break
        case 1://自动轮播
            let scrollViewTestVc:AutoScrollTestViewController = AutoScrollTestViewController()
            scrollViewTestVc.title = showArray[indexPath.row]
            self.navigationController?.pushViewController(scrollViewTestVc, animated: true)
            break
        case 2://日期选择键盘
            let datePickerTestVc:JWDatePickerViewTestViewController = JWDatePickerViewTestViewController()
            datePickerTestVc.title = showArray[indexPath.row]
            self.navigationController?.pushViewController(datePickerTestVc, animated: true)
            break
        case 3://消息图标
            let messageTestVc:JWMessageViewTestViewController = JWMessageViewTestViewController()
            messageTestVc.title = showArray[indexPath.row]
            self.navigationController?.pushViewController(messageTestVc, animated: true)
            break
        case 4://图片展示
            let photoTestVc:PhotoBrowserTestViewController = PhotoBrowserTestViewController()
            photoTestVc.title = showArray[indexPath.row]
            self.navigationController?.pushViewController(photoTestVc, animated: true)
            break
        case 5://弹出提示
            let progressHUDTestVc:JWProgressHUDTestViewController = JWProgressHUDTestViewController()
            progressHUDTestVc.title = showArray[indexPath.row]
            self.navigationController?.pushViewController(progressHUDTestVc, animated: true)
            break
        case 6://webView
            let webTestVc:JWWebViewController = JWWebViewController()
            webTestVc.urlString = "https://www.baidu.com"
            webTestVc.title = showArray[indexPath.row]
            self.navigationController?.pushViewController(webTestVc, animated: true)
            break
        case 7://日历控件
            let calendarVc:JWCalendarViewController = JWCalendarViewController()
            
            calendarVc.addDate(date: Date(), forState: DayItemState.disabled)
            
            var dateComps:DateComponents = DateComponents()
            dateComps.year = 2017
            dateComps.month =  6
            dateComps.day =  10
            calendarVc.scrollToCurrent(dateComps: dateComps, animated: true)
            
            var MaxDateComps:DateComponents = DateComponents()
            MaxDateComps.year = 2017
            MaxDateComps.month =  10
            MaxDateComps.day =  10
            calendarVc.maxDate =  Calendar.current.date(from: MaxDateComps)
            
            calendarVc.title = showArray[indexPath.row]
            calendarVc.enableGrid = arc4random_uniform(100) % 2 == 0 
            self.navigationController?.pushViewController(calendarVc, animated: true)
            break
        default:
            break
        }
    }
}

