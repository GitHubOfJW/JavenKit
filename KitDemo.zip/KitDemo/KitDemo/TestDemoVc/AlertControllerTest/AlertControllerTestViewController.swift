//
//  AlertControllerTestViewController.swift
//  KitDemo
//
//  Created by 朱建伟 on 2016/12/29.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//

import UIKit

class AlertControllerTestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func btnClick(_ sender: UIButton) {
        switch sender.tag {
        case 0:
            let alertController:JWAlertController = JWAlertController(preferredStyle: JWAlertControllerStyle.popover, sourceView: sender)
            
            alertController.addAction(actionTitle: "联系客服", actionStyle: .default, handler: { (action) in
                
            })
            alertController.addAction(actionTitle: "联系卖家", actionStyle: .default, handler: { (action) in
                
            })
            self.present(alertController, animated: true, completion: {
                
            })
            break
        case 1://actionsheet
            let alertController:JWAlertController = JWAlertController(preferredStyle: JWAlertControllerStyle.actionSheet)
            alertController.addAction(actionTitle: "相机", actionStyle: .default, handler: { (action) in
                
            })
            alertController.addAction(actionTitle: "相册", actionStyle: .default, handler: { (action) in
                
            })
            alertController.addAction(actionTitle: "查看大图", actionStyle: .default, handler: { (action) in
                
            })
            alertController.addAction(actionTitle: "取消", actionStyle: .default, handler: { (action) in
                
            })
            self.present(alertController, animated: true, completion: { 
                
            })
            break
        case 2://alert
            let alertController:JWAlertController = JWAlertController(title: "好评提醒", message: "亲，给个好评吧，我们非常需要您的鼓励哦！", preferredStyle: JWAlertControllerStyle.alert)
            
            alertController.addAction(actionTitle: "立即好评", actionStyle: .default, handler: { (action) in
                
            })
            alertController.addAction(actionTitle: "残忍拒绝", actionStyle: .default, handler: { (action) in
                
            })
            
            self.present(alertController, animated: true, completion: {
                
            })
            break
        case 3://alert
            let alertController:JWAlertController = JWAlertController(title: "温馨提示", message: "确认要删除吗？厉害了我的哥", preferredStyle: JWAlertControllerStyle.alert)
            alertController.addAction(actionTitle: "直接删除", actionStyle: .default, handler: { (action) in
                
            })
            alertController.addAction(actionTitle: "查看详情", actionStyle: .default, handler: { (action) in
                
            })
            alertController.addAction(actionTitle: "取消", actionStyle: .default, handler: { (action) in
                
            })
            self.present(alertController, animated: true, completion: {
                
            })

            break
        case 4://popover
            let alertController:JWAlertController = JWAlertController(preferredStyle: JWAlertControllerStyle.popover, sourceView: sender)
            
            alertController.addAction(actionTitle: "联系客服", actionStyle: .default, handler: { (action) in
                
            })
            alertController.addAction(actionTitle: "联系卖家", actionStyle: .default, handler: { (action) in
                
            })
            self.present(alertController, animated: true, completion: {
                
            })
            break
        default:
            break
            
        }
    }
    
 
}
