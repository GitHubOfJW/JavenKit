//
//  PhotoBrowserTestViewController.swift
//  KitDemo
//
//  Created by 朱建伟 on 2016/12/30.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//

import UIKit

class PhotoBrowserTestViewController: UIViewController {

    @IBOutlet var imageBtns: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        for btn in imageBtns{
            btn.imageView?.contentMode = .scaleAspectFill
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
 
    @IBAction func imageBtnClick(_ sender: UIButton) {
        let  browserVc:JWPhotoBrowserViewController =  JWPhotoBrowserViewController(photoCount: self.imageBtns.count, showIndex: sender.tag, thumbnailClosure:  {(index,imageView, completionClosure) in
             
            completionClosure(self.imageBtns[index].image(for: .normal))
            
        }, bigImageClosure: {(index,imageView, completionClosure) in
            
            completionClosure(self.imageBtns[index].image(for: .normal))
            
        }, sourceViewClosure: {
            (index) in
            return (self.imageBtns[index],self.imageBtns[index].image(for: .normal))
        })
        
        self.present(browserVc, animated: true, completion: {
            
        })
    }

}
