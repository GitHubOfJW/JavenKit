//
//  JWProgressHUDTestViewController.swift
//  KitDemo
//
//  Created by 朱建伟 on 2016/12/30.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//

import UIKit

class JWProgressHUDTestViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func btnClick(_ sender: UIButton) {
        switch sender.tag {
        case 0:
            JavenHUD.showMessage(message: "", type: JWProgressHUDType.loading, complectionClosure: { 
                //加载中
            })
            
            
            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()+2.5, execute: {
                if arc4random_uniform(100)%2==0{
                    JavenHUD.showMessage(message: "", type: JWProgressHUDType.dismiss, complectionClosure: {
                        //消失
                    })
                }else{
                    JavenHUD.showMessage(message: "加载成功", type: JWProgressHUDType.success, complectionClosure: {
                        //成功
                    })
                }
            })
            break
        case 1:
            JavenHUD.showMessage(message: "加载成功", type: JWProgressHUDType.success, complectionClosure: {
                //成功
            })
            break
        case 2:
            JavenHUD.showMessage(message: "加载失败", type: JWProgressHUDType.error, complectionClosure: {
                //成功
            })
            break
        case 3:
            JavenHUD.showMessage(message: "展示纯文字的信息，不想使用带图标的失败或成功提示，可以直接用它来代替", type: JWProgressHUDType.message, complectionClosure: {
                //成功
            })
            break
        default:
            break
        }
    }
    
    
}
