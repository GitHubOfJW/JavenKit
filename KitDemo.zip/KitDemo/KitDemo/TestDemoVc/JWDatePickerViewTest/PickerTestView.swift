//
//  HomeView.swift
//  CarServer
//
//  Created by 朱建伟 on 2016/10/23.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//

import UIKit

class PickerTestView: UIView {

    
    //时间展示控件
    let pickerView:JWDatePickerView = JWDatePickerView()
    
    //开始时间
    let startTimeField:UITextField = UITextField()
    
    //当前时间
    let currentTimeField:UITextField = UITextField()
    
    //结束时间
    let endTimeField:UITextField = UITextField()
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        startTimeField.placeholder = "开始时间"
        currentTimeField.placeholder = "当前时间"
        endTimeField.placeholder = "结束时间"
        
        pickerView.backgroundColor = UIColor.red
        
        //日期控件
        addSubview(pickerView)
        
        //开始时间
        addSubview(startTimeField)
        
        //当前
        addSubview(currentTimeField)
        
        //结束时间
        addSubview(endTimeField)
        
    }
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        let pickerViewX:CGFloat = 0
        let pickerViewY:CGFloat = 100
        let pickerViewW:CGFloat = bounds.width
        let pickerViewH:CGFloat = 226
        pickerView.frame =  CGRect(x: pickerViewX, y: pickerViewY, width: pickerViewW, height: pickerViewH)
        
        let startX:CGFloat = 10
        let startY:CGFloat = pickerView.frame.maxY+10
        let startW:CGFloat = bounds.width - 20
        let startH:CGFloat = 30
        startTimeField.frame = CGRect(x: startX, y: startY, width: startW, height: startH)
        
        let  currentX:CGFloat = 10
        let  currentY:CGFloat = startTimeField.frame.maxY + 10
        let  currentW:CGFloat = bounds.width - 20
        let  currentH:CGFloat = 30
        currentTimeField.frame = CGRect(x: currentX, y: currentY, width: currentW, height: currentH)
        
        let endX:CGFloat =  10
        let endY:CGFloat =  currentTimeField.frame.maxY+10
        let endW:CGFloat = bounds.width - 20
        let endH:CGFloat = 30
        endTimeField.frame =  CGRect(x: endX, y: endY, width: endW, height: endH)
        
     }
    
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    
}
