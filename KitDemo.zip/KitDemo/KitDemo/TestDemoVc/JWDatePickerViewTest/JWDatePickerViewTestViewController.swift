//
//  TestViewController.swift
//  CarServer
//
//  Created by 朱建伟 on 2016/12/6.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//

import UIKit

class JWDatePickerViewTestViewController: UIViewController {
    
    let homeView:PickerTestView =  PickerTestView()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        view.backgroundColor = UIColor.white
 
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(title: "切换限制", style: UIBarButtonItemStyle.done, target: self, action: #selector(JWDatePickerViewTestViewController.rightNavButtonClick(item:)))
        
       homeView.frame = view.bounds
        homeView.pickerView.pickerMode = JWDatePickerMode.dateAndTimeRYear
        
        weak var weakSelf = self
        
        let dateF:DateFormatter = DateFormatter()
        dateF.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        
        let startInputView:JWDatePickerKeyBoardView = JWDatePickerKeyBoardView(frame:CGRect(x: 0, y: 0, width: view.bounds.width, height: 216))
        
        startInputView.didConfirmDateClosure = {
            (date) -> Void in
            weakSelf?.homeView.startTimeField.text = dateF.string(from: date)
            weakSelf?.homeView.pickerView.minDate = date
        };
        
        
        homeView.startTimeField.inputView =  startInputView
        
        
        
        
        let currentInputView:JWDatePickerKeyBoardView = JWDatePickerKeyBoardView(frame:CGRect(x: 0, y: 0, width: view.bounds.width, height: 216))
        
        currentInputView.didConfirmDateClosure = {
            (date) -> Void in
            weakSelf?.homeView.currentTimeField.text = dateF.string(from: date)
            weakSelf?.homeView.pickerView.date = date
        };
        
        homeView.currentTimeField.inputView =  currentInputView
        
        
        
        let endInputView:JWDatePickerKeyBoardView = JWDatePickerKeyBoardView(frame:CGRect(x: 0, y: 0, width: view.bounds.width, height: 216))
        
        endInputView.didConfirmDateClosure = {
            (date) -> Void in
            weakSelf?.homeView.endTimeField.text = dateF.string(from: date)
            weakSelf?.homeView.pickerView.maxDate = date
        };
        
        homeView.endTimeField.inputView =  endInputView
        
        homeView.pickerView.didSelectedDateClosure = {
            (date)-> Void in
            weakSelf?.homeView.currentTimeField.text = dateF.string(from: date)
        }
        
        view.addSubview(homeView)
        
        
        //头部
        let titleBtn:UIButton =  UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 20))
        titleBtn.setTitle("切换模式", for: UIControlState.normal)
        titleBtn.setTitleColor(UIColor.red, for: UIControlState.normal)
        titleBtn.addTarget(self, action: #selector(JWDatePickerViewTestViewController.changeMode), for: UIControlEvents.touchUpInside)
        navigationItem.titleView = titleBtn
    }
    
    
    func  changeMode() {
        if self.homeView.pickerView.pickerMode == .dateAndTimeForAllComponent{
            self.homeView.pickerView.pickerMode = .dateAndTime
        }else{
            self.homeView.pickerView.pickerMode = JWDatePickerMode(rawValue:(self.homeView.pickerView.pickerMode?.rawValue)! + 1)
        }
    }
  
    
    
    
    func rightNavButtonClick(item: UIBarButtonItem) {
        self.homeView.pickerView.enableLimited =  !self.homeView.pickerView.enableLimited!
    }
}
