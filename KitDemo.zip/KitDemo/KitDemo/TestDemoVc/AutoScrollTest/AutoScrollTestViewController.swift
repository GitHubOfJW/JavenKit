//
//  AutoScrollTestViewController.swift
//  KitDemo
//
//  Created by 朱建伟 on 2016/12/29.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//

import UIKit

class AutoScrollTestViewController: UIViewController,JWAutoScrollViewDelegate{

    let autoScrollView:JWAutoScrollView = JWAutoScrollView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.backgroundColor = UIColor.white

        self.automaticallyAdjustsScrollViewInsets = false
        autoScrollView.frame = CGRect(x: 0, y: 64, width: view.bounds.width, height: 200)
        autoScrollView.delegate = self
        view.addSubview(autoScrollView)
        
    }

    
    //每一次自动滚动停止
    func autoScrollView(autoScrollView: JWAutoScrollView, didEndAnimationAt itemIndex: Int) {
        
    }
    
    //返回自动滚动的个数
    func autoScrollViewNumberOfPage() -> Int {
        return 4
    }
    
    //本方法将 每一个item返回，使用者可以通过框架加载图片  也可以直接设置本地图片
    func autoScrollView(autoScrollView: JWAutoScrollView, index: Int, imageButton: JWAutoScrollViewButton) {
        
        
        imageButton.setImage(UIImage(named:String(format:"%zd",index)), for: UIControlState.normal)
        
    }
    
    //点击选中
    func autoScrollView(autoScrollView: JWAutoScrollView, didSelectedItemAt itemIndex: Int) {
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
