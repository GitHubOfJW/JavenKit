//
//  ViewController.swift
//  JWMessageView
//
//  Created by 朱建伟 on 2016/12/1.
//  Copyright © 2016年 zhujianwei. All rights reserved.
//

import UIKit

class JWMessageViewTestViewController: UIViewController {

    var messageView:JWMessageView =  JWMessageView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        self.view.backgroundColor = UIColor.white
        
        messageView.frame = CGRect(x: 150, y: 150, width: 60, height: 20)
        
        view.addSubview(messageView)
        
        messageView.messageCount = 10
        
        
        
        let promptLabel:UILabel = UILabel(frame: CGRect(x: 0, y: view.bounds.height - 40, width: view.bounds.width, height: 30))
        promptLabel.text = "点击屏幕刷新消息图标"
        promptLabel.textAlignment = NSTextAlignment.center
        view.addSubview(promptLabel)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        super.touchesEnded(touches, with: event)
        
        self.messageView.messageCount = Int(arc4random_uniform(100))
    }


}

